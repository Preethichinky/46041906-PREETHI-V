package today05;

public class MovieTicket 
{
	String candidateName;
	String movieName;
	int hallNumber;
	int seatNo;
	Float ticketPrice;
	public String getCandidateName() 
	{
		return candidateName;
	}
	public void setCandidateName(String candidateName) 
	{
		this.candidateName = candidateName;
	}
	public String getMovieName() 
	{
		return movieName;
	}
	public void setMovieName(String movieName) 
	{
		this.movieName = movieName;
	}
	public int getHallNumber() 
	{
		return hallNumber;
	}
	public void setHallNumber(int hallNumber) 
	{
		this.hallNumber = hallNumber;
	}
	public int getSeatNo() 
	{
		return seatNo;
	}
	public void setSeatNo(int seatNo) 
	{
		this.seatNo = seatNo;
	}
	public Float getTicketPrice() 
	{
		return ticketPrice;
	}
	public void setTicketPrice(Float ticketPrice) 
	{
		this.ticketPrice = ticketPrice;
	}
	
}
