package labprograms;

public class Sumofcubes 
{
	public static void main(String args[])
	{
		int sum=0,n=5;
		for(int i=0;i<=n;i++)
		{
			sum=sum+i*i*i;
		}
		System.out.println("The value is " +sum);
	}
}
