package labprograms5;

public class EmployeeException extends Exception 
{

	public EmployeeException(String message) 
	{
		// TODO Auto-generated constructor stub
		super(message);
	}
	
}
