package october;

public class BookDetails 
{
	private String bookId;
	
	public BookDetails(String bookId)
	{
		this.setBookId(bookId);
	}

	public String getBookId() {
		return bookId;
	}

	public void setBookId(String bookId) {
		this.bookId = bookId;
	}
	
	public boolean equals(Object o)
	{
		System.out.println("From map");
		if(o!= null && o instanceof BookDetails)
		{
			String bookNumber =((BookDetails)o).getBookId();
			if(bookNumber!=null && bookNumber.equals(this.getBookId()))
				return true;
			
		}
		return false;
	}
	public int hashCode()
	{
		System.out.println("From Map...");
		return this.bookId.hashCode();
	}
}
