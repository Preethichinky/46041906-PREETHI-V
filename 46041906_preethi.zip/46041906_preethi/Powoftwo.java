package labprograms;

public class Powoftwo 
{
	public static boolean isPowerOfTwo(int number) 
	{
	    if (number % 2 != 0) 
	    {
	    	return false;
	    } 
	    else 
	    {
	    	for (int i = 0; i <= number; i++) 
	    	{
	    		if (Math.pow(2, i) == number) 
	    			return true;
	    	}
	    }
	    return false;
	  }
	public static void main(String args[])
	{
		int number=15;
		if (isPowerOfTwo(number)) 
		{
		      System.out.println("yes");
		} 
		else 
		{
		      System.out.printf("no");
		}
	}
}
