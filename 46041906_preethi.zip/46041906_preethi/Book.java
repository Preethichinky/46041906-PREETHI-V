package october;

public class Book 
{
	private int books;

	public int getBooks() {
		return books;
	}

	public void setBooks(int books) {
		this.books = books;
	}
	
	public Book()
	{
		this.books=(int)((Math.random()*101)+1);
	}
}
