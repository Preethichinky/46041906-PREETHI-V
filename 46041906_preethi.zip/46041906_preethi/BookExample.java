package october;

import java.util.HashMap;
import java.util.Map;

public class BookExample 
{
	public static class BookEmp
	{
		public static void main(String args[]) 
		{
			BookDetails b=new BookDetails("M123th");
			BookDetails b1=new BookDetails("M123th");
			System.out.println(b.equals(b1));
			  
			Map<BookDetails,Book> bookNumber=new HashMap<BookDetails,Book>();
		    
			 bookNumber.put(b1, new Book());
			 bookNumber.put(b1, new Book());
			  
			  System.out.println(bookNumber.size());
			  
		}
	}
}
