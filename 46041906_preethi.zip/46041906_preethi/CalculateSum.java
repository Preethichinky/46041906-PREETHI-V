package labprograms;

public class CalculateSum 
{
	public void sum()
	{
		int n=25,sum=0;
		for(int i=0;i<=n;i++)
		{
			if(i%3==0 && i%5==0)
			{
				sum=sum+i;
			}
		}
		System.out.println(sum);
	}
	public static void main(String args[])
	{
		CalculateSum ca= new CalculateSum();
		ca.sum();
	}
}
