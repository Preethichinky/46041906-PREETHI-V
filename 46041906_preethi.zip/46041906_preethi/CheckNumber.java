package labprograms;

public class CheckNumber 
{
	public static void main(String args[])
	{
		//boolean demo()
		{
			int number=1234;
			boolean x=false;
			int digit=number%10;
			number=number/10;
			while(number>0)
			{
				if(digit<=number%10)
				{
					digit=number%10;
					break;
				}
				digit=number%10;
				number=number/10;
			}
			if(x)
			{
				System.out.println("Digits are not in increasing order");
			}
			else
			{
				System.out.println("Digits are in increasing order");
			}
		}
	}
}
