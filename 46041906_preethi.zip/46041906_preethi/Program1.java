package labprograms5;

public class Program1 
{
		public static void main(String args[]) 
		{
			Program1 le1 = new Program1();
			try 
			{
				System.out.println(le1.validateAge(16));
				System.out.println(le1.validateAge(12));
			}
			catch(InvalidAgeException e) 
			{
				System.out.println(e);
			}
		}
		public int validateAge(int age) throws InvalidAgeException 
		{
			if(age<=15) 
			{
				throw new InvalidAgeException("Age should be greater then 15");
			}
			else
				System.out.println("Age is valid");
			return age;
		}
	
}
