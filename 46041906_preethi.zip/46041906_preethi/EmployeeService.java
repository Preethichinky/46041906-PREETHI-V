
package com.cg.eis.service;

public interface EmployeeService {
	public void information();
	public void insuranceScheme();
	public void display();	
}