package labprograms;

import java.util.Arrays;
import java.util.Scanner;

public class PositiveName 
{
	static Scanner sc= new Scanner(System.in);
	public static boolean acceptInput(String s)
	{
		//s=sc.next();
		char[] c = new char[s.length()];
		for(int i=0;i<s.length();i++)
		{
			c[i]=s.charAt(i);
		}
		Arrays.sort(c);
		for(int i=0;i<s.length();i++)
		{
			if(c[i]!=s.charAt(i))
			{
				return false;
			}
		}
		return true;
	}
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		String s=sc.next();
		if(acceptInput(s))
		{
			System.out.println("Positive String");
		}
		else
		{
			System.out.println("Not Positive String");
		}
	}
}
