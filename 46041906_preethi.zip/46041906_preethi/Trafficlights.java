package labprograms;

import java.util.Scanner;

public class Trafficlights 
{
	public static void main(String args[])
	{
		int n;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a number:");
		n=sc.nextInt();
		switch(n)
		{
			case 0:System.out.println("Red");break;
			case 1:System.out.println("Yellow");break;
			case 2:System.out.println("Green");break;
			default:System.out.println(" ");break;
		}
	}
}
