package today05;

import java.util.Scanner;
public class MovieTicketDetails 
{
	public void display()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Candidate Name:");
		String candidateName=sc.nextLine();
		System.out.println("Enter the Movie Name:");
		String movieName=sc.next();
		System.out.println("Enter the Hall Number:");
		int hallnumber=sc.nextInt();
		System.out.println("Enter the Seat Number:");
		int seatNo=sc.nextInt();
		System.out.println("Enter the Ticket Price:");
		Float ticketPrice=sc.nextFloat();
		
		sc.close();
		
		System.out.println("The candidate's name is :"+candidateName);
		System.out.println("The movie name is :"+movieName);
		System.out.println("The Hall Number is :"+hallnumber);
		System.out.println("The Seat Number is:"+seatNo);
		System.out.println("The Ticket Price is:"+ticketPrice);
		
	}
	public static void main(String args[])
	{
		MovieTicket movie = new MovieTicket();
		MovieTicketDetails m = new MovieTicketDetails();
		m.display();
	}
	
}
